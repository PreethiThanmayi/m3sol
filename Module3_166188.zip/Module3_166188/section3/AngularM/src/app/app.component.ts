import { Component } from '@angular/core';

@Component({
    
    selector: 'two',
    templateUrl: 'app.component.html',
    
})
export class TwoWayComponent {

  username:String ;
  email:String;
  password:String;
}
