package com.cg.service;

import com.cg.bean.RegisterBean;

public interface StudentService {

	boolean isValid(String percent);

	

}
