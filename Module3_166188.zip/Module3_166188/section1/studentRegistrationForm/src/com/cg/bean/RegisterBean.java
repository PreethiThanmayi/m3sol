package com.cg.bean;

public class RegisterBean {

private String studentName;
private String studentDept;
private String  marks_12;
private String mobileNumber;
private String percentage;


public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public String getStudentDept() {
	return studentDept;
}
public void setStudentDept(String studentDept) {
	this.studentDept = studentDept;
}
public String getMarks_12() {
	return marks_12;
}
public void setMarks_12(String marks_12) {
	this.marks_12 = marks_12;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getPercentage() {
	return percentage;
}
public void setPercentage(String percentage) {
	this.percentage = percentage;
}



}
